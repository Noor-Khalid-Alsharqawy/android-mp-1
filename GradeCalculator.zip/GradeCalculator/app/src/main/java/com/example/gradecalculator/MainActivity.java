package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText quizMark= findViewById(R.id.quizes); quizMark.setText("0.0");
        EditText hwMark= findViewById(R.id.homeworks); hwMark.setText("0.0");
        EditText mtaMark= findViewById(R.id.MTAs); mtaMark.setText("0.0");
        EditText finalMark= findViewById(R.id.quizes); finalMark.setText("0.0");
        TextView results= findViewById(R.id.show_result);
        Button calculate= findViewById(R.id.calculate_button);
        Button reset= findViewById(R.id.reset_button);

        //rest action is easy
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quizMark.setText("0.0"); hwMark.setText("0.0");
                mtaMark.setText("0.0"); finalMark.setText("0.0");
            }
        });

        //calculate button action
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                results.setText(0.15*Double.parseDouble(quizMark.getText().toString())
                        + 0.25*Double.parseDouble(hwMark.getText().toString())
                        + 0.3*Double.parseDouble(mtaMark.getText().toString())
                        + 0.3*Double.parseDouble(finalMark.getText().toString()) + "");
            }
        });



    }
}